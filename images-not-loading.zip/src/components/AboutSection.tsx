'use client'

import { motion } from 'framer-motion'
import { useInView } from 'framer-motion'
import { useRef } from 'react'
import Image from 'next/image'
import { ArrowRight } from 'lucide-react'

export default function AboutSection() {
  const ref = useRef(null)
  const isInView = useInView(ref, { once: true, margin: '-100px' })

  return (


      <section ref={ref} className="py-0 lg:py-0">
        <div className="max-w-full mx-auto">
          <div className="grid lg:grid-cols-2 gap-0">
            {/* Text Side */}
            <motion.div
              initial={{ opacity: 0, x: -30 }}
              animate={isInView ? { opacity: 1, x: 0 } : { opacity: 0, x: -30 }}
              transition={{ duration: 0.8 }}
              className="bg-cream px-8 lg:px-16 py-16 lg:py-24 flex flex-col justify-center h-[400px] lg:h-[600px]"
            >
              <div className="space-y-8 max-w-xl">
                <h2 className="font-serif text-5xl lg:text-6xl font-normal text-olive leading-tight">
                  Live a fulfilling life.
                </h2>
                
                <div className="space-y-4 text-olive font-normal text-base lg:text-base">
                  <p>
                    Life can be challenging—especially when you're trying to balance your personal and professional life.
                  </p>
                  
                  <p>
                    It's easy to feel like you're alone in facing these challenges, but I want you to know that I'm here to help.
                  </p>
                </div>

                <motion.a
                  href="#contact"
                  whileHover={{ x: 5 }}
                  whileTap={{ scale: 0.98 }}
                  className="inline-flex items-center gap-2 text-olive hover:text-olive-light transition-colors duration-300 font-normal tracking-widest text-xs uppercase pt-4"
                >
                  GET IN TOUCH
                  <ArrowRight className="w-4 h-4" />
                </motion.a>
              </div>
            </motion.div>

            {/* Image Side */}
            <motion.div
              initial={{ opacity: 0, x: 30 }}
              animate={isInView ? { opacity: 1, x: 0 } : { opacity: 0, x: 30 }}
              transition={{ duration: 0.8, delay: 0.2 }}
              className="relative h-[400px] lg:h-[600px]"
            >
              <Image
                src="/images/journal-coffee.jpg"
                alt="Therapy and wellness setup"
                fill
                className="object-cover"
                sizes="(max-width: 768px) 100vw, 50vw"
              />
            </motion.div>
          </div>
        </div>
      </section>
  )
}
