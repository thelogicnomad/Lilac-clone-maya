'use client'

import { motion } from 'framer-motion'
import { useInView } from 'framer-motion'
import { useRef } from 'react'
import Image from 'next/image'

const specialties = [
  {
    title: 'Self-Esteem',
    description: "Building a strong sense of self-worth is key to living a fulfilled life. Let's work together to bolster your self-esteem.",
    image: '/images/specialty-self-esteem.jpg',
  },
  {
    title: 'Relationships',
    description: "Navigating relationships can be complex. I'm here to guide you through these complexities to help you form healthier connections.",
    image: '/images/specialty-relationships.jpg',
  },
  {
    title: 'Burnout',
    description: "Feeling overwhelmed by your career is more common than you think. Together, we'll identify strategies to manage and prevent burnout.",
    image: '/images/specialty-burnout.jpg',
  },
]

export default function SpecialtiesSection() {
  const ref = useRef(null)
  const isInView = useInView(ref, { once: true, margin: '-100px' })

  return (
    <section ref={ref} className="py-20 lg:py-32 px-6 lg:px-12 bg-cream">
      <div className="max-w-7xl mx-auto">
        <motion.h2
          initial={{ opacity: 0, y: 20 }}
          animate={isInView ? { opacity: 1, y: 0 } : { opacity: 0, y: 20 }}
          transition={{ duration: 0.6 }}
          className="font-serif text-5xl lg:text-6xl font-normal text-olive text-center mb-20 lg:mb-32"
        >
          My Specialties
        </motion.h2>

        <div className="grid md:grid-cols-3 gap-8 lg:gap-8">
          {specialties.map((specialty, index) => (
            <motion.div
              key={specialty.title}
              initial={{ opacity: 0, y: 30 }}
              animate={isInView ? { opacity: 1, y: 0 } : { opacity: 0, y: 30 }}
              transition={{ duration: 0.6, delay: index * 0.2 }}
              className="group"
            >
              <div className="border-2 border-olive bg-cream p-8 h-full flex flex-col transition-all duration-300">
                <h3 className="font-serif text-2xl font-normal text-olive mb-6">{specialty.title}</h3>
                
                <p className="text-olive font-normal text-base mb-12 flex-grow">
                  {specialty.description}
                </p>

                <motion.div
                  whileHover={{ scale: 1.02 }}
                  transition={{ duration: 0.3 }}
                  className="relative w-full h-64 rounded-full overflow-hidden"
                >
                  <Image
                    src={specialty.image || "/placeholder.svg"}
                    alt={specialty.title}
                    fill
                    className="object-cover"
                    sizes="(max-width: 768px) 100vw, 33vw"
                  />
                </motion.div>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  )
}
