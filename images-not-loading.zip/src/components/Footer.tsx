'use client'

import Link from 'next/link'

export default function Footer() {
  return (
    <footer className="bg-cream border-t border-olive/10 py-12 px-6 lg:px-12">
      <div className="max-w-7xl mx-auto">
        <div className="flex flex-col md:flex-row items-center justify-between gap-6">
          <div className="text-olive font-light">
            <p className="text-2xl mb-2">Lilac Template</p>
            <p className="text-sm text-olive-light">© 2025 All rights reserved.</p>
          </div>
          
          <nav className="flex items-center gap-8">
            <Link
              href="/blog"
              className="text-olive hover:text-lavender transition-colors duration-300 font-light"
            >
              Blog
            </Link>
            <Link
              href="/contact"
              className="text-olive hover:text-lavender transition-colors duration-300 font-light"
            >
              Contact
            </Link>
            <Link
              href="#privacy"
              className="text-olive hover:text-lavender transition-colors duration-300 font-light text-sm"
            >
              Privacy Policy
            </Link>
          </nav>
        </div>
      </div>
    </footer>
  )
}
