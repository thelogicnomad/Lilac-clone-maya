'use client'

import { motion } from 'framer-motion'
import Link from 'next/link'
import Image from 'next/image'
import Header from '@/components/Header'
import Footer from '@/components/Footer'
import ScrollProgress from '@/components/ScrollProgress'

const blogPosts = [
  {
    id: 1,
    title: 'Understanding Self-Esteem and Its Impact',
    excerpt: 'Exploring how self-esteem affects our daily lives and relationships.',
    image: 'https://images.unsplash.com/photo-1593811167562-9cef47bfc4d7',
    date: 'January 15, 2025',
    category: 'Self-Esteem'
  },
  {
    id: 2,
    title: 'Navigating Complex Relationships',
    excerpt: 'Tips and strategies for building healthier connections with others.',
    image: 'https://images.unsplash.com/photo-1522075782449-e45a34f1ddfb',
    date: 'January 10, 2025',
    category: 'Relationships'
  },
  {
    id: 3,
    title: 'Managing Burnout in Modern Life',
    excerpt: 'Recognizing the signs of burnout and strategies for recovery.',
    image: 'https://images.unsplash.com/photo-1506126613408-eca07ce68773',
    date: 'January 5, 2025',
    category: 'Burnout'
  },
]

export default function BlogPage() {
  return (
    <main className="min-h-screen">
      <ScrollProgress />
      <Header />
      
      <section className="pt-32 pb-20 px-6 lg:px-12">
        <div className="max-w-7xl mx-auto">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            className="text-center mb-16"
          >
            <h1 className="text-5xl lg:text-6xl font-light text-olive mb-6">Blog</h1>
            <p className="text-xl text-olive-light font-light max-w-2xl mx-auto">
              Insights and resources for your mental health journey
            </p>
          </motion.div>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {blogPosts.map((post, index) => (
              <motion.article
                key={post.id}
                initial={{ opacity: 0, y: 30 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6, delay: index * 0.1 }}
                whileHover={{ y: -8 }}
                className="group cursor-pointer"
              >
                <Link href={`/blog/${post.id}`}>
                  <div className="bg-beige border border-olive/10 overflow-hidden transition-all duration-300 group-hover:border-lavender group-hover:shadow-lg">
                    <div className="relative h-64 overflow-hidden">
                      <Image
                        src={post.image}
                        alt={post.title}
                        fill
                        className="object-cover group-hover:scale-110 transition-transform duration-500"
                      />
                    </div>
                    <div className="p-6 space-y-3">
                      <div className="flex items-center justify-between text-sm text-olive-light">
                        <span>{post.category}</span>
                        <span>{post.date}</span>
                      </div>
                      <h2 className="text-2xl font-light text-olive group-hover:text-lavender transition-colors">
                        {post.title}
                      </h2>
                      <p className="text-olive-light font-light">
                        {post.excerpt}
                      </p>
                    </div>
                  </div>
                </Link>
              </motion.article>
            ))}
          </div>
        </div>
      </section>

      <Footer />
    </main>
  )
}
