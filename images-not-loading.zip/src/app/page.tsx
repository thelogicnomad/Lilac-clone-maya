'use client'

import Header from '@/components/Header'
import HeroSection from '@/components/HeroSection'
import AboutSection from '@/components/AboutSection'
import SpecialtiesSection from '@/components/SpecialtiesSection'
import CTASection from '@/components/CTASection'
import Footer from '@/components/Footer'
import ScrollProgress from '@/components/ScrollProgress'

export default function Home() {
  return (
    <main className="min-h-screen">
      <ScrollProgress />
      <Header />
      <HeroSection />
      <AboutSection />
      <SpecialtiesSection />
      <CTASection />
      <Footer />
    </main>
  )
}
